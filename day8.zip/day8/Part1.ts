import * as fs from 'fs';

class JunctionBox {
    constructor(
        public x: number,
        public y: number,
        public z: number,
    ) {}
}

class Relationship {
    public euclideanDistance: number;
    public key1: string;
    public key2: string;

    constructor(
        box1: JunctionBox,
        box2: JunctionBox
    ) {
        this.key1 = this.getKey(box1);
        this.key2 = this.getKey(box2);
        this.euclideanDistance = this.getDistance(box1, box2);
    }

    getKey(box: JunctionBox): string {
        return `${box.x},${box.y},${box.z}`;
    }

    getDistance(box1: JunctionBox, box2: JunctionBox): number {
        return Math.sqrt((box1.x - box2.x) ** 2 + (box1.y - box2.y) ** 2 + (box1.z - box2.z) ** 2);
    }
}

class Part1 {
    private boxes: JunctionBox[];
    private relationships: Relationship[];
    private connections: Set<string>[];
    private totalCircuits;

    constructor(public fileName: string) {
        this.boxes = this.parseInput(fileName);
        this.relationships = this.getRelationships();
        this.connections = [];
        this.totalCircuits = 0;
    }  

    private parseInput(fileName: string): JunctionBox[] {
        const output = [];
        const file = fs.readFileSync(`${fileName}.txt`, 'ascii').trim().split(/\n/);
        for (const line of file) {
            const parts = line.trim().split(",");
            if (parts.length !== 3) throw new Error('Invalid input');
            output.push(new JunctionBox(parseInt(parts[0]!), parseInt(parts[1]!), parseInt(parts[2]!)))
        }
        console.log("Boxes assigned");
        return output;
    }

    private getRelationships(): Relationship[] {
        const sortedRelationships: Relationship[] = [];
        for (let i = 0; i < this.boxes.length - 1; i++) {
            const box1 = this.boxes[i]!;
            for (let j = i + 1; j < this.boxes.length; j++) {
                const box2 = this.boxes[j]!;
                const relationship = new Relationship(box1, box2);
                this.addRelationship(relationship, sortedRelationships);
            }
        }
        console.log("Relationships assigned");
        return sortedRelationships;
    }

    private addRelationship(rel: Relationship, sortedRelationships: Relationship[]) {
        if (sortedRelationships.length === 0) sortedRelationships.push(rel);
        else if (sortedRelationships[0]!.euclideanDistance > rel.euclideanDistance) sortedRelationships.splice(0,0, rel);
        else if (sortedRelationships[sortedRelationships.length - 1]!.euclideanDistance < rel.euclideanDistance) sortedRelationships.push(rel);
        else {
            let i = 0;
            let j;
            let added = false;
            while (i < sortedRelationships.length - 1) {
                j = i + 1;
                if (sortedRelationships[i]!.euclideanDistance < rel.euclideanDistance && sortedRelationships[j]!.euclideanDistance > rel.euclideanDistance) {
                    sortedRelationships.splice(j, 0, rel);
                    added = true;
                    break;
                } else if (sortedRelationships[i]!.euclideanDistance === rel.euclideanDistance) {
                    sortedRelationships.splice(i, 0, rel);
                    added = true;
                    break;
                } else if (sortedRelationships[j]!.euclideanDistance === rel.euclideanDistance) {
                    sortedRelationships.splice(j, 0, rel);
                    added = true;
                    break;
                }
                i++;
            }
            if (!added) {
                console.log(rel, sortedRelationships)
                throw new Error('Valid index not found')
            };
        }
    }

    private getCurrentSets(key1:string, key2:string) {
        const sets = [];
        for (const set of this.connections) {
            if (set.has(key1) || set.has(key2)) sets.push(set);
        }
        if (sets.length > 2) throw new Error("Incorrect logic for sets");
        return sets;
    }

    private connectBoxes(numberOfBoxes: number) {
        for (let i = 0; i < numberOfBoxes; i++) {
            const curr = this.relationships[i];
            console.log(curr?.key1, curr?.key2);
            const existing =  this.getCurrentSets(curr!.key1, curr!.key2);
            if (existing.length === 0) {
                const newSet = new Set<string>();
                newSet.add(curr!.key1);
                newSet.add(curr!.key2);
                this.connections.push(newSet);
            } else if (existing.length === 1) {
                // const sizeBefore = existing[0]?.size;
                existing[0]!.add(curr!.key1);
                existing[0]!.add(curr!.key2);
                // const sizeAfter = existing[0]?.size;
                // if (sizeBefore === sizeAfter) breakPoint++;
            } else { // 2 sets
                existing[1]?.forEach(el => existing[0]?.add(el));
                this.connections.filter(set => set === existing[1]);
            }
        }
        this.totalCircuits = this.connections.length + (this.boxes.length - numberOfBoxes);
    }

    run() {
        console.log(this.relationships);
        this.connectBoxes(this.fileName === "example" ? 10 : 1000);
        console.log(this.connections);
        console.log(this.totalCircuits);
    }
}

const solution = new Part1("example");
solution.run();